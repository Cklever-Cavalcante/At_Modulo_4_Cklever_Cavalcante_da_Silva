import React from 'react';

function Contact() {
  return (
   <>
   <div className="back_re">
     <div className="container">
       <div className="row">
         <div className="col-md-12">
           <div className="title">
             <h2>Registre-se abaixo</h2>
           </div>
         </div>
       </div>
     </div>
   </div>
   <div className="contact">
     <div className="container">
       <div className="row">
         <div className="col-md-6">
           <form id="request" className="main_form">
             <div className="row">
               <div className="col-md-12 ">
                 <input
                   className="contactus"
                   placeholder="Nome"
                   type="type"
                   name="Nome"
                 />
               </div>
               <div className="col-md-12">
                 <input
                   className="contactus"
                   placeholder="E-mail"
                   type="type"
                   name="Email"
                 />
               </div>
               <div className="col-md-12 ">
                 <input
                   className="contactus"
                   placeholder="Telefone"
                   type="type"
                   name="Telefone"
                 />
               </div>
               <div className="col-md-12 ">
                 <input
                   className="contactus"
                   placeholder="Cidade"
                   type="type"
                   name="Cidade"
                 />
               </div>
               <div className="col-md-12 ">
                 <input
                   className="contactus"
                   placeholder="Uf"
                   type="type"
                   name="Uf"
                 />
               </div>
               <div className="col-md-12">
                 <input
                   className="contactus"
                   placeholder="País"
                   type="type"
                   name="País"
                 />
               </div>
               <div className="col-md-12">
                 <textarea
                   className="textarea"
                   placeholder="Mensagem"
                   type="type"
                   message="Mensagem"
                   defaultValue={"Mensagem"}
                 />
               </div>
               <div className="col-md-12">
                 <button className="send_btn">Enviar</button>
               </div>
             </div>
           </form>
         </div>
         <div className="col-md-6">
           <div className="map_main">
             <div className="map-responsive">
               <iframe
                 src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA0s1a7phLN0iaD6-UE7m4qP-z21pH0eSc&q=Eiffel+Tower+Paris+France"
                 width={600}
                 height={400}
                 frameBorder={0}
                 style={{ border: 0, width: "100%" }}
                 allowFullScreen=""
               />
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
 </>
  );
}

export default Contact;